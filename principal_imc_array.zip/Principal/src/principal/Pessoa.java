package principal;

 public class Pessoa {
    float peso, altura;

    Pessoa(float peso, float altura) {
        this.peso = peso;
        this.altura = altura;
    }
}

